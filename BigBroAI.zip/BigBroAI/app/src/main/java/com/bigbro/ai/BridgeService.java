package com.bigbro.ai;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;

import java.util.ArrayList;
import java.util.Locale;

public class BridgeService extends Service {
    static final String CHANNEL = "bigbro_ai";

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Handler ph = new Handler(Looper.getMainLooper()); // ตัวถามสถานะปุ่มไมค์ในเกม
    private boolean polling = false;
    private SpeechRecognizer sr;
    private boolean live = false;
    private volatile boolean speaking = false;
    private TextToSpeech tts;
    private boolean ttsReady = false;

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public void onCreate() {
        super.onCreate();
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("th", "TH"));
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String id) { speaking = true; }
                    @Override public void onDone(String id) { speaking = false; }
                    @Override public void onError(String id) { speaking = false; }
                });
                ttsReady = true;
            }
        });
        Bridge.get().speaker = text -> {
            if (ttsReady && prefs().getBoolean("speak", true)) {
                speaking = true;
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "bro");
            }
        };
    }

    private SharedPreferences prefs() { return getSharedPreferences("cfg", MODE_PRIVATE); }

    private boolean hasMicPermission() {
        return checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;
        if ("STOP".equals(action)) {
            stopPolling();
            stopLive();
            Bridge.get().stop();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }
        boolean wantLive = prefs().getBoolean("live", true) && !"LIVE_OFF".equals(action);
        boolean mic = wantLive && hasMicPermission();
        startAsForeground(mic);
        Bridge.get().start(prefs().getString("key", ""), prefs().getString("model", ""));
        if (mic) {
            startPolling(); // ปุ่มไมค์ในเกม (ช่อง 9) เป็นคนสั่งเปิด/ปิดไมค์มือถือ
        } else {
            stopPolling();
            stopLive();
            if (wantLive) Bridge.get().log("ยังไม่ได้อนุญาตไมค์ — ไปที่ตั้งค่าแอปแล้วเปิดสิทธิ์ไมโครโฟน");
        }
        return START_STICKY;
    }

    private void startAsForeground(boolean mic) {
        NotificationManager nm = getSystemService(NotificationManager.class);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                new NotificationChannel(CHANNEL, "BigBro AI", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Notification n = b.setContentTitle("BigBro AI ทำงานอยู่")
            .setContentText(mic ? "กดปุ่มไมค์ในเกมเพื่อเปิด/ปิดไมค์ • /connect 127.0.0.1:3000" : "/connect 127.0.0.1:3000")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .build();
        if (Build.VERSION.SDK_INT >= 30) {
            int type = ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
                | (mic ? ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE : 0);
            startForeground(1, n, type);
        } else if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC);
        } else {
            startForeground(1, n);
        }
    }

    // ---------------- ปุ่มไมค์ในเกม คุมไมค์มือถือ ----------------
    private final Runnable pollTask = new Runnable() {
        @Override public void run() {
            if (!polling) return;
            if (!Bridge.get().isGameConnected()) {
                if (live) stopLive(); // เกมหลุด -> ปิดไมค์เพื่อความเป็นส่วนตัว
            } else {
                Bridge.get().queryMicOn(on -> h.post(() -> {
                    if (!polling || on == null) return;
                    if (on && !live) startLive();
                    else if (!on && live) stopLive();
                }));
            }
            ph.postDelayed(this, 1000);
        }
    };

    private void startPolling() {
        if (polling) return;
        polling = true;
        ph.post(pollTask);
    }

    private void stopPolling() {
        polling = false;
        ph.removeCallbacksAndMessages(null);
    }

    // ---------------- ฟังไมค์มือถือ (ตอนปุ่มในเกมเปิด) ----------------
    private void startLive() {
        if (live) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Bridge.get().log("เครื่องนี้ไม่มีตัวรู้จำเสียง (ต้องมีแอป Google)");
            return;
        }
        live = true;
        Bridge.get().log("🎤 เปิดไมค์แล้ว (ตามปุ่มในเกม) — พูดขึ้นต้นด้วย 'พี่โต' หรือ 'จ๊ะจ๋า'");
        h.post(this::listenOnce);
    }

    private void stopLive() {
        if (!live && sr == null) return;
        live = false;
        h.removeCallbacksAndMessages(null);
        if (sr != null) { try { sr.destroy(); } catch (Exception ignored) {} sr = null; }
        Bridge.get().log("🎤 ปิดไมค์แล้ว");
    }

    private void restart(long delayMs) {
        h.postDelayed(this::listenOnce, delayMs);
    }

    private void listenOnce() {
        if (!live) return;
        if (speaking) { restart(500); return; }
        try {
            if (sr == null) {
                sr = SpeechRecognizer.createSpeechRecognizer(this);
                sr.setRecognitionListener(new RecognitionListener() {
                    @Override public void onReadyForSpeech(Bundle p) {}
                    @Override public void onBeginningOfSpeech() {}
                    @Override public void onRmsChanged(float v) {}
                    @Override public void onBufferReceived(byte[] b) {}
                    @Override public void onEndOfSpeech() {}
                    @Override public void onPartialResults(Bundle p) {}
                    @Override public void onEvent(int t, Bundle p) {}

                    @Override public void onResults(Bundle r) {
                        ArrayList<String> list = r.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                        if (!speaking && list != null && !list.isEmpty()) {
                            Bridge.get().voice(list.get(0), prefs().getBoolean("needName", true), true);
                        }
                        restart(300);
                    }

                    @Override public void onError(int error) {
                        if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                            Bridge.get().log("ไม่มีสิทธิ์ไมโครโฟน");
                            live = false;
                            return;
                        }
                        if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) {
                            try { sr.destroy(); } catch (Exception ignored) {}
                            sr = null;
                            restart(1000);
                        } else if (error == SpeechRecognizer.ERROR_NO_MATCH
                                || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                            restart(300);
                        } else {
                            restart(1500);
                        }
                    }
                });
            }
            Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH");
            i.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, getPackageName());
            sr.startListening(i);
        } catch (Exception e) {
            Bridge.get().log("mic error: " + e.getMessage());
            restart(2000);
        }
    }

    @Override public void onDestroy() {
        stopPolling();
        stopLive();
        Bridge.get().speaker = null;
        Bridge.get().stop();
        if (tts != null) tts.shutdown();
        super.onDestroy();
    }
}
