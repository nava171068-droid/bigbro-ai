package com.bigbro.ai;

import org.java_websocket.WebSocket;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/** สะพาน Minecraft (/connect 127.0.0.1:3000) <-> Groq AI */
public class Bridge {
    public interface Listener {
        void onLog(String line);
    }

    private static final Bridge INSTANCE = new Bridge();
    public static Bridge get() { return INSTANCE; }

    private static final String GROQ_URL = "https://api.groq.com/openai/v1/chat/completions";
    private static final int PORT = 3000;
    private static final String[] NAMES = {"พี่โต", "จ๊ะจ๋า"};
    private static final String[][] ALIASES = {
        {"พี่โต", "พี่โตะ"},
        {"จ๊ะจ๋า", "จะจ๋า", "จ๋าจ๋า", "จ้ะจ๋า", "จ๊ะจ้า"}
    };
    private static final String[] COLORS = {"§e", "§d"};
    private static final String[] PERSONAS = {
        "คุณคือ 'พี่โต' พี่ชายใจดี เป็นเพื่อนสนิทและผู้ช่วยของผู้เล่นใน Minecraft Bedrock "
        + "คุณรู้เรื่อง Minecraft ดี เช่น สูตรคราฟต์ แร่ มอนสเตอร์ การสร้างบ้าน เรดสโตน ฟาร์ม การเอาชีวิตรอด "
        + "เวลาให้ข้อมูลให้ตอบตรงประเด็นและถูกต้อง ถ้าไม่แน่ใจหรือเรื่องอาจเปลี่ยนตามเวอร์ชัน ให้บอกตรง ๆ "
        + "นอกจากนั้นคุยเล่นเป็นเพื่อนได้ พูดไทยเป็นกันเอง เรียกผู้เล่นว่า 'น้อง' หรือ 'เพื่อน' "
        + "คุณมีน้องสาวชื่อ 'จ๊ะจ๋า' ที่ไปผจญภัยด้วยกัน พูดถึงน้องได้เป็นบางครั้งตามความเหมาะสม",
        "คุณคือ 'จ๊ะจ๋า' น้องสาวของ 'พี่โต' เด็กสดใสน่ารักที่เป็นเพื่อนของผู้เล่นใน Minecraft Bedrock "
        + "คุณช่วยตอบเรื่อง Minecraft ได้ด้วย (สูตรคราฟต์ มอนสเตอร์ การสร้าง การเอาชีวิตรอด) ตอบให้ถูกต้อง "
        + "ถ้าไม่แน่ใจให้บอกตรง ๆ และชวนคุยเล่นได้ พูดไทยสดใส ลงท้ายจ้า/น้า "
        + "เรียกพี่ชายว่า 'พี่โต' และพูดถึงพี่โตได้เป็นบางครั้ง"
    };
    private static final String RULES =
        " ตอบสั้น กระชับ ไม่เกิน 3 ประโยค เป็นข้อความธรรมดา ไม่ใช้ markdown ไม่ใช้อีโมจิ อยู่ในบทบาทตัวละครเสมอ";

    public volatile Listener listener;
    public volatile java.util.function.Consumer<String> speaker;
    private final StringBuilder logBuf = new StringBuilder();
    private final ExecutorService ex = Executors.newCachedThreadPool();
    private final ScheduledExecutorService sched = Executors.newSingleThreadScheduledExecutor();
    private final Map<String, CompletableFuture<JSONObject>> pending = new ConcurrentHashMap<>();
    private final Map<String, List<JSONObject>> history = new ConcurrentHashMap<>();
    private final Set<String> busy = ConcurrentHashMap.newKeySet();
    private volatile WebSocket game;
    private Server server;
    private volatile String apiKey = "";
    private volatile String model = "llama-3.3-70b-versatile";

    private Bridge() {}

    public synchronized void configure(String key, String mdl) {
        if (key != null) apiKey = key.trim();
        if (mdl != null && !mdl.trim().isEmpty()) model = mdl.trim();
    }

    public synchronized void start(String key, String mdl) {
        configure(key, mdl);
        if (server != null) return;
        server = new Server();
        server.setReuseAddr(true);
        server.start();
        log("เริ่มเซิร์ฟเวอร์แล้ว -> ในเกมพิมพ์ /connect 127.0.0.1:" + PORT);
    }

    public synchronized void stop() {
        if (server == null) return;
        try { server.stop(1000); } catch (Exception ignored) {}
        server = null;
        game = null;
        log("หยุดเซิร์ฟเวอร์แล้ว");
    }

    public synchronized boolean isRunning() { return server != null; }

    public String logs() {
        synchronized (logBuf) { return logBuf.toString(); }
    }

    void log(String s) {
        synchronized (logBuf) {
            logBuf.append(s).append('\n');
            if (logBuf.length() > 6000) logBuf.delete(0, logBuf.length() - 5000);
        }
        Listener l = listener;
        if (l != null) l.onLog(s);
    }

    /**
     * ข้อความที่แปลงจากเสียงไมค์มือถือ
     * requireName = ต้องพูดขึ้นต้นด้วยชื่อ, gate = เคารพปุ่มไมค์ในเกม (ปิดไมค์ในเกม = ไม่ตอบ)
     */
    public void voice(String text, boolean requireName, boolean gate) {
        final String t = text == null ? "" : text.trim();
        if (t.isEmpty()) return;
        int[] m = match(t);
        if (m == null && requireName) return;
        final int who = m != null ? m[0] : 0;
        final String q = m != null ? strip(t, m[1]) : t;
        if (q.isEmpty()) return;
        log("🎤 " + t);
        ex.submit(() -> {
            if (gate) {
                try {
                    JSONObject r = runCommand("testfor @a[tag=bro_mic_off]").get(4, TimeUnit.SECONDS);
                    if (r.optInt("statusCode", -1) == 0) return;
                } catch (Exception ignored) {}
            }
            ask(who, "voice", q);
        });
    }

    public boolean isGameConnected() {
        WebSocket g = game;
        return g != null && g.isOpen();
    }

    /** ถามเกมว่าปุ่มไมค์เปิดอยู่ไหม: true = เปิด, false = ปิด, null = ไม่รู้ (ไม่ได้เชื่อมต่อ/ไม่ตอบ) */
    public void queryMicOn(java.util.function.Consumer<Boolean> cb) {
        runCommand("testfor @a[tag=!bro_mic_off]").whenComplete((r, err) -> {
            if (err != null || r == null || !r.has("statusCode")) { cb.accept(null); return; }
            cb.accept(r.optInt("statusCode", -1) == 0);
        });
    }

    // ---------------- WebSocket ฝั่งเกม ----------------
    private class Server extends WebSocketServer {
        Server() { super(new InetSocketAddress("127.0.0.1", PORT)); }

        @Override public void onOpen(WebSocket c, ClientHandshake h) {
            game = c;
            log("เกมเชื่อมต่อแล้ว");
            try {
                JSONObject head = new JSONObject()
                    .put("version", 1)
                    .put("requestId", UUID.randomUUID().toString())
                    .put("messagePurpose", "subscribe")
                    .put("messageType", "commandRequest");
                JSONObject body = new JSONObject().put("eventName", "PlayerMessage");
                c.send(new JSONObject().put("header", head).put("body", body).toString());
            } catch (Exception e) { log("subscribe error: " + e.getMessage()); }
        }

        @Override public void onClose(WebSocket c, int code, String reason, boolean remote) {
            if (game == c) game = null;
            log("เกมตัดการเชื่อมต่อ");
        }

        @Override public void onMessage(WebSocket c, String msg) { onGameMessage(msg); }

        @Override public void onError(WebSocket c, Exception e) {
            log("error: " + e.getMessage());
        }

        @Override public void onStart() {}
    }

    private void onGameMessage(String raw) {
        try {
            JSONObject m = new JSONObject(raw);
            JSONObject h = m.optJSONObject("header");
            if (h == null) return;
            if ("commandResponse".equals(h.optString("messagePurpose"))) {
                CompletableFuture<JSONObject> f = pending.remove(h.optString("requestId"));
                if (f != null) {
                    JSONObject b = m.optJSONObject("body");
                    f.complete(b != null ? b : new JSONObject());
                }
                return;
            }
            if (!"PlayerMessage".equals(h.optString("eventName"))) return;
            JSONObject b = m.optJSONObject("body");
            if (b == null || !"chat".equals(b.optString("type"))) return;
            final String sender = b.optString("sender");
            final String text = b.optString("message").trim();
            ex.submit(() -> handleChat(sender, text));
        } catch (Exception e) {
            log("parse error: " + e.getMessage());
        }
    }

    private void handleChat(String sender, String text) {
        int[] m = match(text);
        if (m == null) return;
        int idx = m[0];
        String q = strip(text, m[1]);
        if (q.isEmpty()) { say(idx, "ว่าไงครับ? พิมพ์คำถามต่อท้ายชื่อได้เลย"); return; }

        log(sender + ": " + text);
        ask(idx, sender, q);
    }

    private CompletableFuture<JSONObject> runCommand(String line) {
        final CompletableFuture<JSONObject> f = new CompletableFuture<>();
        WebSocket g = game;
        if (g == null || !g.isOpen()) { f.complete(new JSONObject()); return f; }
        try {
            final String id = UUID.randomUUID().toString();
            JSONObject head = new JSONObject()
                .put("version", 1)
                .put("requestId", id)
                .put("messagePurpose", "commandRequest")
                .put("messageType", "commandRequest");
            JSONObject body = new JSONObject()
                .put("version", 1)
                .put("commandLine", line)
                .put("origin", new JSONObject().put("type", "player"));
            pending.put(id, f);
            g.send(new JSONObject().put("header", head).put("body", body).toString());
            sched.schedule(() -> {
                if (pending.remove(id) != null) f.complete(new JSONObject());
            }, 4, TimeUnit.SECONDS);
        } catch (Exception e) {
            log("send error: " + e.getMessage());
            f.complete(new JSONObject());
        }
        return f;
    }

    // ---------------- AI ----------------
    private void ask(int idx, String sender, String question) {
        if (apiKey.isEmpty()) { log("ยังไม่ได้ใส่ Groq API key"); return; }
        String key = sender + "|" + idx;
        if (!busy.add(key)) return;
        try {
            List<JSONObject> hist = history.computeIfAbsent(key, k -> new ArrayList<>());
            JSONArray msgs = new JSONArray();
            msgs.put(new JSONObject().put("role", "system").put("content", PERSONAS[idx] + RULES));
            synchronized (hist) { for (JSONObject o : hist) msgs.put(o); }
            JSONObject user = new JSONObject().put("role", "user").put("content", question);
            msgs.put(user);

            String reply = callGroq(msgs);

            synchronized (hist) {
                hist.add(user);
                hist.add(new JSONObject().put("role", "assistant").put("content", reply));
                while (hist.size() > 8) hist.remove(0);
            }
            say(idx, reply);
        } catch (Exception e) {
            log("Groq error: " + e.getMessage());
            say(idx, "§cตอนนี้คุยไม่ได้ ลองใหม่อีกที");
        } finally {
            busy.remove(key);
        }
    }

    private String callGroq(JSONArray msgs) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(GROQ_URL).openConnection();
        c.setRequestMethod("POST");
        c.setConnectTimeout(15000);
        c.setReadTimeout(30000);
        c.setDoOutput(true);
        c.setRequestProperty("Authorization", "Bearer " + apiKey);
        c.setRequestProperty("Content-Type", "application/json");
        c.setRequestProperty("User-Agent", "BigBroAI/1.0");
        JSONObject body = new JSONObject()
            .put("model", model)
            .put("max_tokens", 250)
            .put("temperature", 0.8)
            .put("messages", msgs);
        try (OutputStream os = c.getOutputStream()) {
            os.write(body.toString().getBytes(StandardCharsets.UTF_8));
        }
        int code = c.getResponseCode();
        InputStream is = (code >= 200 && code < 300) ? c.getInputStream() : c.getErrorStream();
        String resp = readAll(is);
        if (code < 200 || code >= 300) {
            throw new IOException(code + " " + resp.substring(0, Math.min(200, resp.length())));
        }
        return new JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content").trim();
    }

    private static String readAll(InputStream is) throws IOException {
        if (is == null) return "";
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(is, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) sb.append(line).append('\n');
        }
        return sb.toString();
    }

    // ---------------- ตอบกลับ ----------------
    private void say(int idx, String text) {
        String clean = text.replaceAll("\\s+", " ").trim();
        log("<" + NAMES[idx] + "> " + clean.replaceAll("§.", ""));
        java.util.function.Consumer<String> sp = speaker;
        if (sp != null) sp.accept(clean.replaceAll("§.", ""));
        for (int i = 0; i < clean.length(); i += 180) {
            try {
                String part = clean.substring(i, Math.min(clean.length(), i + 180));
                JSONObject piece = new JSONObject()
                    .put("text", "<" + COLORS[idx] + NAMES[idx] + "§r> " + part);
                JSONObject msg = new JSONObject().put("rawtext", new JSONArray().put(piece));
                runCommand("tellraw @a " + msg.toString().replace("\\/", "/"));
            } catch (Exception e) { log("tellraw error: " + e.getMessage()); }
        }
    }

    /** คืน {ตัวละคร, ความยาวชื่อที่พูด} หรือ null — ยอมให้มีช่องว่างแทรกและชื่อที่ฟังเพี้ยนบางแบบ */
    private static int[] match(String text) {
        String t = text.startsWith("@") ? text.substring(1) : text;
        String norm = t.replace(" ", "");
        for (int i = 0; i < ALIASES.length; i++)
            for (String a : ALIASES[i])
                if (norm.startsWith(a)) return new int[]{i, a.length()};
        return null;
    }

    private static String strip(String text, int nameLen) {
        String t = text.startsWith("@") ? text.substring(1) : text;
        int i = 0, c = 0;
        while (i < t.length() && c < nameLen) { if (t.charAt(i) != ' ') c++; i++; }
        return t.substring(i).replaceFirst("^[\\s,:]+", "").trim();
    }
}
