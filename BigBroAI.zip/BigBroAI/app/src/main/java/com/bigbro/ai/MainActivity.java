package com.bigbro.ai;

import android.Manifest;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends Activity implements Bridge.Listener {
    private static final int REQ_VOICE = 1;
    private static final int REQ_PERMS = 7;
    private EditText keyEt, modelEt;
    private CheckBox liveCb, nameCb, speakCb;
    private TextView logTv;
    private ScrollView sv;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        SharedPreferences sp = getSharedPreferences("cfg", MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        root.setPadding(pad, pad * 2, pad, pad);

        TextView title = new TextView(this);
        title.setText("BigBro AI (Groq)");
        title.setTextSize(22);
        root.addView(title);

        keyEt = new EditText(this);
        keyEt.setHint("Groq API key (gsk_...)");
        keyEt.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        keyEt.setText(sp.getString("key", ""));
        root.addView(keyEt);

        modelEt = new EditText(this);
        modelEt.setHint("ชื่อโมเดล");
        modelEt.setText(sp.getString("model", "llama-3.3-70b-versatile"));
        root.addView(modelEt);

        liveCb = new CheckBox(this);
        liveCb.setText("🎤 ให้ปุ่มไมค์ในเกม (ช่อง 9) เปิด/ปิดไมค์มือถือ");
        liveCb.setChecked(sp.getBoolean("live", true));
        liveCb.setOnCheckedChangeListener((v, on) -> {
            saveConfig();
            if (on) startBridge();
            else startService(new Intent(this, BridgeService.class).setAction("LIVE_OFF"));
        });
        root.addView(liveCb);

        nameCb = new CheckBox(this);
        nameCb.setText("ตอบเฉพาะตอนพูดขึ้นต้นด้วยชื่อ (พี่โต / จ๊ะจ๋า)");
        nameCb.setChecked(sp.getBoolean("needName", true));
        nameCb.setOnCheckedChangeListener((v, on) -> saveConfig());
        root.addView(nameCb);

        speakCb = new CheckBox(this);
        speakCb.setText("ให้พี่โตพูดตอบด้วยเสียง");
        speakCb.setChecked(sp.getBoolean("speak", true));
        speakCb.setOnCheckedChangeListener((v, on) -> saveConfig());
        root.addView(speakCb);

        Button startBtn = new Button(this);
        startBtn.setText("เริ่ม / บันทึกคีย์");
        startBtn.setOnClickListener(v -> { saveConfig(); startBridge(); });
        root.addView(startBtn);

        Button stopBtn = new Button(this);
        stopBtn.setText("หยุดทั้งหมด");
        stopBtn.setOnClickListener(v -> startService(new Intent(this, BridgeService.class).setAction("STOP")));
        root.addView(stopBtn);

        Button micBtn = new Button(this);
        micBtn.setText("🎤 กดพูดครั้งเดียว");
        micBtn.setOnClickListener(v -> listenOnce());
        root.addView(micBtn);

        sv = new ScrollView(this);
        logTv = new TextView(this);
        logTv.setTextSize(14);
        sv.addView(logTv);
        root.addView(sv, new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    private void saveConfig() {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("key", keyEt.getText().toString().trim())
            .putString("model", modelEt.getText().toString().trim())
            .putBoolean("live", liveCb.isChecked())
            .putBoolean("needName", nameCb.isChecked())
            .putBoolean("speak", speakCb.isChecked())
            .apply();
        Bridge.get().configure(keyEt.getText().toString(), modelEt.getText().toString());
    }

    private void startBridge() {
        if (keyEt.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "ใส่ Groq API key ก่อน", Toast.LENGTH_SHORT).show();
            return;
        }
        ArrayList<String> need = new ArrayList<>();
        if (Build.VERSION.SDK_INT >= 33
            && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.POST_NOTIFICATIONS);
        if (liveCb.isChecked()
            && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need.add(Manifest.permission.RECORD_AUDIO);
        if (!need.isEmpty() && Build.VERSION.SDK_INT >= 23) {
            requestPermissions(need.toArray(new String[0]), REQ_PERMS);
            return;
        }
        launchService();
    }

    private void launchService() {
        Intent i = new Intent(this, BridgeService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
    }

    @Override public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code == REQ_PERMS) launchService();
    }

    private void listenOnce() {
        saveConfig();
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "th-TH");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "พูดได้เลย");
        try {
            startActivityForResult(i, REQ_VOICE);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "เครื่องนี้ไม่มีตัวรู้จำเสียง (Google)", Toast.LENGTH_LONG).show();
        }
    }

    @Override protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_VOICE && res == RESULT_OK && data != null) {
            ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (r != null && !r.isEmpty()) Bridge.get().voice(r.get(0), false, false);
        }
    }

    @Override protected void onResume() {
        super.onResume();
        Bridge.get().listener = this;
        logTv.setText(Bridge.get().logs());
        sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
    }

    @Override protected void onPause() {
        Bridge.get().listener = null;
        super.onPause();
    }

    @Override public void onLog(String line) {
        runOnUiThread(() -> {
            logTv.append(line + "\n");
            sv.post(() -> sv.fullScroll(View.FOCUS_DOWN));
        });
    }
}
