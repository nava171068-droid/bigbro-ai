# BigBro AI

แอป Android เล็ก ๆ ที่เป็นสะพานระหว่าง Minecraft Bedrock กับ Groq AI

1. ติดตั้ง `addon/BigBro_Mic.mcaddon` ในเกม
2. เปิดแอป ใส่ Groq API key กด "เริ่ม"
3. ในเกมพิมพ์ `/connect 127.0.0.1:3000`
4. พิมพ์แชท `พี่โต ...` หรือ `จ๊ะจ๋า ...` หรือกดปุ่ม 🎤 ในแอปแล้วพูด
